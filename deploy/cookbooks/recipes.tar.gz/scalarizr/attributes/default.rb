default[:scalarizr][:behaviour] = [ "base" ]
